import React from 'react';

const Square = ({ value, onSquareClick }) => {
  return (
    <button className="square" onClick={onSquareClick}>
      {value}
    </button>
  );
}

function calculateWinner(squares) {
  return null;
}

function Rows({ squaresState}) {
  const [squaresState, setSquares] = React.useState(Array(76).fill(null));
  const [xIsNext, setXIsNext] = React.useState(true);

  const winner = calculateWinner(squaresState);

  function handleClick(i) {
    if (squaresState[i] || winner) return;
    const nextSquares = squaresState.slice();
    nextSquares[i] = xIsNext ? 'X' : 'O';
    setSquares(nextSquares);
    setXIsNext(!xIsNext);
  }

  return (
    <>
      <div className="status">{status}</div>
      <div className="board-row">
        <Square value={squaresState[0]} onSquareClick={() => handleClick(0)} />
        <Square value={squaresState[1]} onSquareClick={() => handleClick(1)} />
        <Square value={squaresState[2]} onSquareClick={() => handleClick(2)} />
        <Square value={squaresState[3]} onSquareClick={() => handleClick(3)} />
        <Square value={squaresState[4]} onSquareClick={() => handleClick(4)} />
        <Square value={squaresState[5]} onSquareClick={() => handleClick(5)} />
        <Square value={squaresState[6]} onSquareClick={() => handleClick(6)} />
        <Square value={squaresState[7]} onSquareClick={() => handleClick(7)} />
        <Square value={squaresState[8]} onSquareClick={() => handleClick(8)} />
        <Square value={squaresState[9]} onSquareClick={() => handleClick(9)} />
        <Square value={squaresState[10]} onSquareClick={() => handleClick(10)} />
        <Square value={squaresState[11]} onSquareClick={() => handleClick(11)} />
      </div>
      <div className="board-row">
        <Square value={squaresState[12]} onSquareClick={() => handleClick(12)} />
        <Square value={squaresState[13]} onSquareClick={() => handleClick(13)} />
        <Square value={squaresState[14]} onSquareClick={() => handleClick(14)} />
        <Square value={squaresState[15]} onSquareClick={() => handleClick(15)} />
        <Square value={squaresState[16]} onSquareClick={() => handleClick(16)} />
        <Square value={squaresState[17]} onSquareClick={() => handleClick(17)} />
        <Square value={squaresState[18]} onSquareClick={() => handleClick(18)} />
        <Square value={squaresState[19]} onSquareClick={() => handleClick(19)} />
        <Square value={squaresState[20]} onSquareClick={() => handleClick(20)} />
        <Square value={squaresState[21]} onSquareClick={() => handleClick(21)} />
        <Square value={squaresState[22]} onSquareClick={() => handleClick(22)} />
        <Square value={squaresState[23]} onSquareClick={() => handleClick(23)} />
      </div>
      <div className="board-row">
        <Square value={squaresState[24]} onSquareClick={() => handleClick(24)} />
        <Square value={squaresState[25]} onSquareClick={() => handleClick(25)} />
        <Square value={squaresState[26]} onSquareClick={() => handleClick(26)} />
        <Square value={squaresState[27]} onSquareClick={() => handleClick(27)} />
        <Square value={squaresState[28]} onSquareClick={() => handleClick(28)} />
        <Square value={squaresState[29]} onSquareClick={() => handleClick(29)} />
        <Square value={squaresState[30]} onSquareClick={() => handleClick(30)} />
        <Square value={squaresState[31]} onSquareClick={() => handleClick(31)} />
        <Square value={squaresState[32]} onSquareClick={() => handleClick(32)} />
        <Square value={squaresState[33]} onSquareClick={() => handleClick(33)} />
        <Square value={squaresState[34]} onSquareClick={() => handleClick(34)} />
        <Square value={squaresState[35]} onSquareClick={() => handleClick(35)} />
      </div>
        <div className="board-row">
        <Square value={squaresState[36]} onSquareClick={() => handleClick(36)} />
        <Square value={squaresState[37]} onSquareClick={() => handleClick(37)} />
        <Square value={squaresState[38]} onSquareClick={() => handleClick(38)} />
        <Square value={squaresState[39]} onSquareClick={() => handleClick(39)} />
        <Square value={squaresState[40]} onSquareClick={() => handleClick(40)} />
        <Square value={squaresState[41]} onSquareClick={() => handleClick(41)} />
        <Square value={squaresState[42]} onSquareClick={() => handleClick(42)} />
        <Square value={squaresState[43]} onSquareClick={() => handleClick(43)} />
        <Square value={squaresState[44]} onSquareClick={() => handleClick(44)} />
        <Square value={squaresState[45]} onSquareClick={() => handleClick(45)} />
        <Square value={squaresState[46]} onSquareClick={() => handleClick(46)} />
        <Square value={squaresState[47]} onSquareClick={() => handleClick(47)} />
      </div>
        <div className="board-row">
        <Square value={squaresState[48]} onSquareClick={() => handleClick(48)} />
        <Square value={squaresState[49]} onSquareClick={() => handleClick(49)} />
        <Square value={squaresState[50]} onSquareClick={() => handleClick(50)} />
        <Square value={squaresState[51]} onSquareClick={() => handleClick(51)} />
        <Square value={squaresState[52]} onSquareClick={() => handleClick(52)} />
        <Square value={squaresState[53]} onSquareClick={() => handleClick(53)} />
        <Square value={squaresState[54]} onSquareClick={() => handleClick(54)} />
        <Square value={squaresState[55]} onSquareClick={() => handleClick(55)} />
        <Square value={squaresState[56]} onSquareClick={() => handleClick(56)} />
        <Square value={squaresState[57]} onSquareClick={() => handleClick(57)} />
        <Square value={squaresState[58]} onSquareClick={() => handleClick(58)} />
        <Square value={squaresState[59]} onSquareClick={() => handleClick(59)} />
      </div>
        <div className="board-row">
        <Square value={squaresState[60]} onSquareClick={() => handleClick(60)} />
        <Square value={squaresState[61]} onSquareClick={() => handleClick(61)} />
        <Square value={squaresState[62]} onSquareClick={() => handleClick(62)} />
        <Square value={squaresState[63]} onSquareClick={() => handleClick(63)} />
        <Square value={squaresState[64]} onSquareClick={() => handleClick(64)} />
        <Square value={squaresState[65]} onSquareClick={() => handleClick(65)} />
        <Square value={squaresState[66]} onSquareClick={() => handleClick(66)} />
        <Square value={squaresState[67]} onSquareClick={() => handleClick(67)} />
        <Square value={squaresState[68]} onSquareClick={() => handleClick(68)} />
        <Square value={squaresState[69]} onSquareClick={() => handleClick(69)} />
        <Square value={squaresState[70]} onSquareClick={() => handleClick(70)} />
        <Square value={squaresState[71]} onSquareClick={() => handleClick(71)} />
      </div>
    </>
    );
};
export default Rows;