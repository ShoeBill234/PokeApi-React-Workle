import { useState } from "react";
import Rows from "./src/components/Rows";
import DisplayData from "./src/components/DisplayData";

export default function App() {
  const [count, setCount] = useState(0);

  return (
    <div style={{ fontFamily: "system-ui, sans-serif", padding: "2rem" }}>
      <h1>Pokemon Wordle</h1>
      <p>Your React app is now rendering!</p>
      <button onClick={() => setCount((c) => c + 1)}>
        Clicked {count} times
      </button>
      <Rows />
      <DisplayData />
    </div>
  );
}