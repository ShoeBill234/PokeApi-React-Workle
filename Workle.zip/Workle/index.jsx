import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./app";
import Rows from "./src/components/Rows";
import DisplayData from "./src/components/DisplayData";


const root = createRoot(document.getElementById("root"));
root.render(
  <StrictMode>
    <App />
    <Rows />
    <DisplayData />
  </StrictMode>
);